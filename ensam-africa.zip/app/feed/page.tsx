export default function Feed() {
  return (
    <div style={{ padding:20 }}>
      <h1>Feed</h1>
      <p>Your app is working 🎉</p>
    </div>
  );
}