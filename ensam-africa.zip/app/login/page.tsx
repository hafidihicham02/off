'use client';
import { useRouter } from 'next/navigation';

export default function Login() {
  const router = useRouter();
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100vh' }}>
      <h2>Login</h2>
      <button onClick={() => router.push('/feed')}>Login</button>
    </div>
  );
}