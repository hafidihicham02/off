'use client';
import { useRouter } from 'next/navigation';

export default function Home() {
  const router = useRouter();
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100vh' }}>
      <h1>ENSAM Africa Network 🌍</h1>
      <div style={{ marginTop:20 }}>
        <button onClick={() => router.push('/login')}>Login</button>
        <button onClick={() => router.push('/feed')} style={{ marginLeft:10 }}>Enter</button>
      </div>
    </div>
  );
}